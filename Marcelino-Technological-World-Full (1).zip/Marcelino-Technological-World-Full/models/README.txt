Place realistic .glb/.gltf files here. Filenames used in data.json are examples.
